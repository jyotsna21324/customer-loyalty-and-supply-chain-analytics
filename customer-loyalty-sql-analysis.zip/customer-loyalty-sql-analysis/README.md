# Does Late Delivery Kill Customer Loyalty?
### SQL-based Customer Segmentation & Cohort Retention Analysis

**Dataset:** DataCo Global Supply Chain (180,519 orders, 20,652 unique customers, 2015–2018)
**Tools:** SQL (SQLite — window functions, CTEs), Python (Pandas), Excel

---

## Business Question

Operations teams commonly assume "late deliveries drive customers away." This project tests
that assumption directly with SQL, instead of taking it at face value.

## Approach

1. **RFM Segmentation** — scored every customer on Recency, Frequency, and Monetary value
   using the `NTILE()` window function, then grouped them into business segments
   (Champions, Loyal, At Risk, Needs Attention, Lost/Churned).
2. **Cohort Retention Analysis** — grouped customers by signup month and tracked, month
   over month, what % of each cohort placed another order, using `MIN() OVER()` and a
   chained CTE.
3. **First-Order Impact Test** — used `ROW_NUMBER() OVER (PARTITION BY customer_id)` to
   isolate each customer's first order, then compared repeat-purchase rate for customers
   whose first order was late vs. on-time.

## Key Findings

- **The obvious hypothesis was wrong.** Repeat purchase rate is 58.9% for customers whose
  first order was late vs. 59.5% for on-time — a negligible difference. Late delivery is
  not a meaningful driver of churn in this dataset.
- **The real problem is a retention cliff that hits everyone equally.** Only ~12-14% of
  any monthly cohort returns in any given following month, regardless of delivery
  experience — and the rate doesn't decay further after month 1, meaning the drop-off
  happens immediately after the first purchase.
- **Customer value is highly concentrated.** "Champions" (8.7% of customers) average
  $3,251 lifetime spend vs. $209 for the "Needs Attention" segment — a ~15x gap.

## Recommendation

Since shipping speed doesn't explain the retention gap, retention spend (email campaigns,
second-purchase incentives, loyalty triggers) should target converting first-time buyers
into a second purchase within 30 days — that's where nearly all customer value is
currently lost, independent of delivery performance.

---

## How to Run This Yourself

1. Download the dataset (see `data/README.md`) and place the CSV in `data/`
2. Install dependencies:
   ```
   pip install -r requirements.txt
   ```
3. Load the data into a local SQLite database:
   ```
   python load_data.py data/DataCoSupplyChainDataset.csv
   ```
4. Run the analysis:
   ```
   sqlite3 dataco.db < analysis.sql
   ```
   (or open `dataco.db` in any SQLite client / DB Browser for SQLite and run
   `analysis.sql` there)

## Repo Structure

```
customer-loyalty-sql-analysis/
├── README.md                              # this file
├── analysis.sql                           # full SQL analysis (window functions, CTEs)
├── load_data.py                           # loads CSV into SQLite
├── requirements.txt
├── data/
│   ├── README.md                          # dataset source & column descriptions
│   └── sample_orders.csv                  # 500-row sample of the cleaned data
└── outputs/
    └── Customer_Loyalty_SQL_Analysis.xlsx # insights, charts, cohort retention heatmap
```
